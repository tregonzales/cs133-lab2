package simpledb;

import java.util.*;

/**
 * SeqScan is an implementation of a sequential scan access method that reads
 * each tuple of a table in no particular order (e.g., as they are laid out on
 * disk).
 */
public class SeqScan implements DbIterator {

    private static final long serialVersionUID = 1L;

    private TransactionId transId;

    private int tabId;

    private String tableAl;

    public  HeapFile.HeapFileIterator ourIterator;


    /**
     * Creates a sequential scan over the specified table as a part of the
     * specified transaction.
     * 
     * @param tid
     *            The transaction this scan is running as a part of.
     * @param tableid
     *            the table to scan.
     * @param tableAlias
     *            the alias of this table (needed by the parser); the returned
     *            tupleDesc should have fields with name tableAlias.fieldName
     *            (note: this class is not responsible for handling a case where
     *            tableAlias or fieldName are null. It shouldn't crash if they
     *            are, but the resulting name can be null.fieldName,
     *            tableAlias.null, or null.null).
     */
    public SeqScan(TransactionId tid, int tableid, String tableAlias) {

        transId = tid;
        tabId = tableid;
        tableAl = tableAlias;
    }

    /**
     * @return
     *       return the table name of the table the operator scans. This should
     *       be the actual name of the table in the catalog of the database
     * */
    public String getTableName() {
        return Database.getCatalog().getTableName(tabId);
    }
    
    /**
     * @return Return the alias of the table this operator scans. 
     * */
    public String getAlias()
    {
        return tableAl;
    }

    /**
     * Reset the tableid, and tableAlias of this operator.
     * @param tableid
     *            the table to scan.
     * @param tableAlias
     *            the alias of this table (needed by the parser); the returned
     *            tupleDesc should have fields with name tableAlias.fieldName
     *            (note: this class is not responsible for handling a case where
     *            tableAlias or fieldName are null. It shouldn't crash if they
     *            are, but the resulting name can be null.fieldName,
     *            tableAlias.null, or null.null).
     */
    public void reset(int tableid, String tableAlias) {
        tabId = tableid;
        tableAl = tableAlias;
    }

    public SeqScan(TransactionId tid, int tableid) {
        this(tid, tableid, Database.getCatalog().getTableName(tableid));
    }

    //open what? iterator?
    public void open() throws DbException, TransactionAbortedException {
        // DbFile ourFile = Database.getCatalog().getDatabaseFile(tabId);
        // HeapFile ourHeapFile = (HeapFile)ourFile; // do we have to cast
        // ourIterator = ourHeapFile.HeapFileIterator(transId);

        //HeapFile.HeapFileIterator ourIterator;
        ourIterator.open();
    }

    /**
     * Returns the TupleDesc with field names from the underlying HeapFile,
     * prefixed with the tableAlias string from the constructor. This prefix
     * becomes useful when joining tables containing a field(s) with the same
     * name.
     * 
     * @return the TupleDesc with field names from the underlying HeapFile,
     *         prefixed with the tableAlias string from the constructor.
     */
    public TupleDesc getTupleDesc() {
        return Database.getCatalog().getTupleDesc(tabId);
    }

    public boolean hasNext() throws TransactionAbortedException, DbException {
        return ourIterator.hasNext();
    }

    public Tuple next() throws NoSuchElementException,
            TransactionAbortedException, DbException {
        return ourIterator.next();
    }

    public void close() {
       //ourIterator = iterator();
        ourIterator.close();
    }

    /**
   * Resets the iterator to the start.
   * @throws DbException when rewind is unsupported.
   * @throws IllegalStateException If the iterator has not been opened
   */
    public void rewind() throws DbException, NoSuchElementException,
            TransactionAbortedException {
        //call reset?
    }
}
